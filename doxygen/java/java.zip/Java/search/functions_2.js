var searchData=
[
  ['dlvanswersets_286',['DLVAnswerSets',['../classit_1_1unical_1_1mat_1_1embasp_1_1specializations_1_1dlv_1_1DLVAnswerSets.html#aba3f3268a09a033fa18b5241f95f43f8',1,'it::unical::mat::embasp::specializations::dlv::DLVAnswerSets']]]
];
