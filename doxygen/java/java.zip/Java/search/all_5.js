var searchData=
[
  ['handler_90',['Handler',['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1Handler.html',1,'it::unical::mat::embasp::base']]]
];
