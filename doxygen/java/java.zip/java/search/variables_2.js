var searchData=
[
  ['options_314',['options',['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1Handler.html#abb90ae42e6824d858f68481b9d1ba686',1,'it.unical.mat.embasp.base.Handler.options()'],['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1OptionDescriptor.html#a7ca880b332cf51ae3740b5943259739d',1,'it.unical.mat.embasp.base.OptionDescriptor.options()']]],
  ['output_315',['output',['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1Output.html#af79ae00c128b98af03e4aaab995a4278',1,'it::unical::mat::embasp::base::Output']]]
];
