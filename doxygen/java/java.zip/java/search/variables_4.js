var searchData=
[
  ['separator_317',['separator',['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1InputProgram.html#af35f2c71363088825a4a323bdd8d506d',1,'it.unical.mat.embasp.base.InputProgram.separator()'],['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1OptionDescriptor.html#a196cdb5096886890973fde21005f58e1',1,'it.unical.mat.embasp.base.OptionDescriptor.separator()']]]
];
