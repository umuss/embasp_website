var searchData=
[
  ['inputprogram_275',['InputProgram',['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1InputProgram.html#a2b658ad4d364b289460ea77222260d0c',1,'it.unical.mat.embasp.base.InputProgram.InputProgram()'],['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1InputProgram.html#aff128bf92b8f834d3c9fe4002d58db09',1,'it.unical.mat.embasp.base.InputProgram.InputProgram(final Object inputObj)']]]
];
