var searchData=
[
  ['programs_316',['programs',['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1Handler.html#a62300affa0165e929a5d37dd58d0fdab',1,'it.unical.mat.embasp.base.Handler.programs()'],['../classit_1_1unical_1_1mat_1_1embasp_1_1base_1_1InputProgram.html#aef2e297119da5785059e543f8749bff0',1,'it.unical.mat.embasp.base.InputProgram.programs()']]]
];
