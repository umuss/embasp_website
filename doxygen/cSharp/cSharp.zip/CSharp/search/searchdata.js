var indexSectionsWithContent =
{
  0: "acdehimopsv",
  1: "acdhimops",
  2: "i",
  3: "v",
  4: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Pages"
};

