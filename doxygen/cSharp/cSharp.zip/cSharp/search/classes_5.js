var searchData=
[
  ['mapper_169',['Mapper',['../classit_1_1unical_1_1mat_1_1embasp_1_1languages_1_1Mapper.html',1,'it::unical::mat::embasp::languages']]]
];
