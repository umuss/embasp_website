var searchData=
[
  ['base_10',['base',['../namespacebase.html',1,'']]]
];
