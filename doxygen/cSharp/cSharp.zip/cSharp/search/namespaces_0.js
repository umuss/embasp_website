var searchData=
[
  ['base_192',['base',['../namespacebase.html',1,'']]]
];
